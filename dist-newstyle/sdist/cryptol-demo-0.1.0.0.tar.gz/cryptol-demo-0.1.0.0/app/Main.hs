module Main where

import Cryptol.REPL.Monad
import Cryptol.REPL.Command
import Cryptol.Eval
import Cryptol.ModuleSystem

main :: IO ()
main = do
  putStrLn "Cryptol REPL embedding example coming soon..."
  -- You can run commands, evaluate expressions, or interact with modules here
